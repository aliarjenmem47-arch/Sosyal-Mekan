# Design Guidelines: Social Chat Platform

## Design Approach
**Reference-Based Design** drawing from leading social and messaging platforms:
- **Instagram**: Media-rich feed layouts and stories interface
- **Discord/Telegram**: Modern chat UX patterns and real-time messaging
- **WhatsApp**: Clean conversation threads and media galleries

**Core Design Principles:**
- Mobile-first responsive design optimized for conversations
- Media-centric layouts showcasing photos and videos prominently
- Instant feedback for real-time interactions
- Scannable conversation threads with clear visual hierarchy

## Typography System

**Font Family**: Inter (via Google Fonts CDN) for all text
- Primary: 'Inter', system-ui, sans-serif

**Type Scale:**
- Hero/Display: text-4xl to text-6xl, font-bold (landing hero)
- Page Titles: text-3xl, font-bold
- Section Headers: text-2xl, font-semibold
- Message Sender Names: text-sm, font-semibold
- Message Text: text-base, font-normal
- Timestamps/Meta: text-xs, font-medium
- Buttons: text-sm, font-semibold
- Navigation: text-sm, font-medium

## Layout & Spacing System

**Spacing Primitives (Tailwind units):**
- Primary set: 2, 4, 6, 8, 12, 16
- Use p-4 for tight spacing, p-8 for comfortable sections, p-12/p-16 for generous breathing room

**Container Strategy:**
- Landing page: max-w-7xl for wide sections, max-w-4xl for text content
- Chat interface: Full-width layout with sidebar (w-72) + main chat area (flex-1)
- Mobile: Full-width stack, collapsible sidebar

**Grid Patterns:**
- Media galleries: grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2
- User cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Chat list: Single column, full-width items

## Component Library

### Navigation
- **Desktop**: Horizontal top nav with logo (left), main links (center), user profile dropdown (right) - h-16, sticky top-0
- **Mobile**: Bottom nav bar with 4-5 icons, h-16, fixed bottom-0
- **Chat Sidebar**: Left panel (w-72) with search bar at top, scrollable conversation list, "New Chat" FAB

### Authentication Pages
- Centered card layout (max-w-md) with generous padding (p-8)
- Logo at top, form fields with spacing (space-y-4)
- Social login buttons (if using Replit Auth) stacked below primary form
- Subtle background pattern or gradient, not solid

### Chat Interface (Main Application)
**Three-Column Layout (Desktop):**
1. **Left Sidebar** (w-72): Conversation list, search, user status
2. **Main Chat** (flex-1): Active conversation thread
3. **Right Panel** (w-80, toggleable): Media gallery, shared files, conversation details

**Chat Message Cards:**
- Own messages: Aligned right, max-w-md, rounded-2xl rounded-tr-md
- Others' messages: Aligned left, max-w-md, rounded-2xl rounded-tl-md
- Avatar (h-8 w-8) adjacent to first message in group
- Timestamp below message groups (not every message)
- Spacing: space-y-1 within message groups, space-y-4 between groups

**Message Input:**
- Fixed bottom bar (p-4), full-width, slight elevation
- Flexible textarea with attachment buttons (left), send button (right)
- Height auto-expands up to max-h-32

### Media Components
**Photo/Video Grid:**
- Masonry-style or equal-height grid
- Hover overlay with view count, timestamp
- Lightbox viewer on click with navigation arrows
- Video thumbnails show play icon overlay

**Shared Media Panel:**
- Tabs for Photos/Videos/Files
- Compact grid (grid-cols-3 gap-1) of thumbnails
- "Load More" button at bottom

### User Profile Cards
- Avatar (h-16 w-16 or h-24 w-24 for profiles)
- Name (text-lg font-semibold) + username (text-sm, muted)
- Online status indicator (absolute, bottom-right of avatar, h-3 w-3 rounded-full)
- Action buttons (Message, Add Friend) below bio

### Forms & Inputs
- Text inputs: h-12, px-4, rounded-lg, border focus ring
- Textareas: min-h-24, p-4, rounded-lg
- File upload: Drag-drop zone (min-h-48) with upload icon and instruction text
- Buttons: h-12, px-6, rounded-lg, font-semibold

### Landing Page Structure (Before Login)

**Hero Section (80vh):**
- Two-column split: Left (50%) - headline + subheadline + CTA buttons, Right (50%) - hero image/mockup
- Headline: text-5xl md:text-6xl, font-bold, leading-tight
- Primary CTA: Large button (h-14, px-8), Secondary: Ghost/outline style
- Hero image: Chat interface mockup or friends connecting illustration

**Features Section (py-20):**
- 3-column grid (grid-cols-1 md:grid-cols-3) with icon cards
- Each card: Icon (h-12 w-12), title (text-xl font-semibold), description (text-base)
- Features: Real-time messaging, Media sharing, Group conversations

**How It Works (py-20):**
- Numbered steps (1-2-3) in horizontal flow
- Step cards with large numbers, icons, and descriptions
- Steps: Sign up → Add friends → Start chatting

**Social Proof (py-16):**
- User testimonials: 2-column grid on desktop
- Each testimonial: Avatar, quote, user name + role
- Optional: User count badge ("Join 10,000+ users")

**CTA Section (py-24):**
- Centered content (max-w-2xl)
- Bold headline + supporting text + prominent CTA button
- Background: Subtle gradient or pattern

**Footer (py-12):**
- 3-column layout: Logo + tagline | Quick links | Social media icons
- Newsletter signup inline if applicable
- Copyright notice and links (Terms, Privacy) at bottom

### Icons
**Library**: Heroicons (via CDN)
- Navigation: Home, Message, Users, Settings, Bell
- Actions: Plus, Upload, Image, Video, Send, Paperclip
- Status: Check, CheckCheck (read receipts), Clock

### Accessibility
- Focus rings visible on all interactive elements (ring-2 ring-offset-2)
- Minimum touch targets: 44x44px (h-11 w-11 minimum for icon buttons)
- High contrast text (WCAG AA minimum)
- Alt text for all images and media
- Keyboard navigation throughout (Tab, Enter, Esc)
- Screen reader labels for icon-only buttons

## Animations
**Minimal, Purposeful Motion:**
- Message send: Quick slide-up fade-in (duration-200)
- New message arrival: Subtle bounce or pulse
- Sidebar toggle: Smooth slide transition (duration-300)
- Avatar status change: Gentle pulse on status dot
- NO complex scroll animations or excessive transitions

## Images
**Hero Image**: Large, high-quality mockup of the chat interface showing friends having conversations with photos - positioned on right 50% of hero section

**Feature Icons**: Use Heroicons, no custom illustrations needed

**User Content**: All user-uploaded photos/videos displayed in galleries and message threads

**Profile Avatars**: Circular, user-provided or default placeholder with user initials

## Responsive Breakpoints
- Mobile: < 768px (single column, bottom nav, full-width chat)
- Tablet: 768px - 1024px (collapsible sidebar, 2-column layouts)
- Desktop: > 1024px (full three-column layout, expanded features)