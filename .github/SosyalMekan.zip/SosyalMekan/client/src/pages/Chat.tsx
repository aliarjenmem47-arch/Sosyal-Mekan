import ChatSidebar from "@/components/ChatSidebar";
import MessageThread from "@/components/MessageThread";

export default function Chat() {
  return (
    <div className="flex h-screen">
      <ChatSidebar />
      <div className="flex-1">
        <MessageThread />
      </div>
    </div>
  );
}
