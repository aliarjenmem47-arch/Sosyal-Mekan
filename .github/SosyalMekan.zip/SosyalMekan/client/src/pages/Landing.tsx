import Hero from "@/components/Hero";
import Features from "@/components/Features";
import HowItWorks from "@/components/HowItWorks";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { MessageSquare } from "lucide-react";
import { Link } from "wouter";

export default function Landing() {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <MessageSquare className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">ChatHub</span>
            </Link>
            <div className="flex items-center gap-2">
              <Link href="/login">
                <a>
                  <Button variant="ghost" data-testid="button-nav-login">
                    Giriş Yap
                  </Button>
                </a>
              </Link>
              <Link href="/register">
                <a>
                  <Button data-testid="button-nav-register">Kayıt Ol</Button>
                </a>
              </Link>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>
      <Hero />
      <Features />
      <HowItWorks />
      <CTA />
      <Footer />
    </div>
  );
}
