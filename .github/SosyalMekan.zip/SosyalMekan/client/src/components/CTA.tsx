import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export default function CTA() {
  return (
    <section className="py-24 bg-gradient-to-br from-primary/10 via-primary/5 to-background">
      <div className="container mx-auto px-4 max-w-4xl text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-6">
          Hemen Başlamaya Hazır mısın?
        </h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          Bugün katıl ve arkadaşlarınla kesintisiz iletişimin keyfini çıkar.
          Ücretsiz hesap oluştur!
        </p>
        <Button size="lg" className="h-14 px-8" data-testid="button-cta-join">
          Ücretsiz Katıl
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </section>
  );
}
