import MessageInput from "../MessageInput";

export default function MessageInputExample() {
  return (
    <div className="max-w-2xl">
      <MessageInput />
    </div>
  );
}
