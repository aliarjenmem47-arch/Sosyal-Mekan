import MessageThread from "../MessageThread";

export default function MessageThreadExample() {
  return (
    <div className="h-screen">
      <MessageThread />
    </div>
  );
}
