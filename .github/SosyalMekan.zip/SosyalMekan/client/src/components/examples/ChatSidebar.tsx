import ChatSidebar from "../ChatSidebar";

export default function ChatSidebarExample() {
  return (
    <div className="h-screen">
      <ChatSidebar />
    </div>
  );
}
