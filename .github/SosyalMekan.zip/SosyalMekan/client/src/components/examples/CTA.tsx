import CTA from "../CTA";

export default function CTAExample() {
  return <CTA />;
}
