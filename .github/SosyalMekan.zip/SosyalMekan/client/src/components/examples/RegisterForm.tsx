import RegisterForm from "../RegisterForm";

export default function RegisterFormExample() {
  return <RegisterForm />;
}
