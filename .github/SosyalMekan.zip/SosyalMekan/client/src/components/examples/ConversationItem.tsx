import ConversationItem from "../ConversationItem";

export default function ConversationItemExample() {
  return (
    <div className="max-w-sm space-y-2 p-4">
      <ConversationItem
        name="Ahmet Yılmaz"
        lastMessage="Bugün kahve içelim mi?"
        timestamp="10:30"
        online={true}
        unreadCount={2}
        active={true}
      />
      <ConversationItem
        name="Ayşe Demir"
        lastMessage="Fotoğrafları gördün mü?"
        timestamp="Dün"
        online={true}
      />
      <ConversationItem
        name="Mehmet Kaya"
        lastMessage="Teşekkürler!"
        timestamp="2 gün önce"
        online={false}
      />
    </div>
  );
}
