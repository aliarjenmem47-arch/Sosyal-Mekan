import UserAvatar from "../UserAvatar";

export default function UserAvatarExample() {
  return (
    <div className="flex gap-4 items-center p-8">
      <UserAvatar name="Ahmet Yılmaz" size="sm" online={true} />
      <UserAvatar name="Ayşe Demir" size="md" online={false} />
      <UserAvatar name="Mehmet Kaya" size="lg" />
    </div>
  );
}
