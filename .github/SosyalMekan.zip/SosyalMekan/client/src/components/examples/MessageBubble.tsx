import MessageBubble from "../MessageBubble";

export default function MessageBubbleExample() {
  return (
    <div className="space-y-4 p-8 max-w-2xl">
      <MessageBubble
        sender="Ahmet Yılmaz"
        message="Merhaba! Nasılsın?"
        timestamp="10:15"
        isOwn={false}
      />
      <MessageBubble
        sender="Sen"
        message="İyiyim, teşekkürler!"
        timestamp="10:16"
        isOwn={true}
      />
      <MessageBubble
        sender="Ahmet Yılmaz"
        message="Bu fotoğrafa bak!"
        timestamp="10:17"
        isOwn={false}
        media={{ type: "image", url: "" }}
      />
    </div>
  );
}
