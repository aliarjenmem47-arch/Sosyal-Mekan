import { Button } from "@/components/ui/button";
import { MessageSquare, ArrowRight } from "lucide-react";
import heroImage from "@assets/generated_images/Chat_app_interface_mockup_cb494f26.png";

export default function Hero() {
  return (
    <section className="min-h-[80vh] flex items-center py-20">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
              <MessageSquare className="h-4 w-4" />
              <span>Yeni Nesil Mesajlaşma</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold leading-tight">
              Arkadaşlarınızla{" "}
              <span className="text-primary">Bağlantıda Kalın</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl">
              Gerçek zamanlı mesajlaşma, fotoğraf ve video paylaşımı ile
              arkadaşlarınızla her an iletişimde olun. Modern, hızlı ve
              kullanıcı dostu.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="h-14 px-8" data-testid="button-get-started">
                Hemen Başla
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-14 px-8"
                data-testid="button-learn-more"
              >
                Daha Fazla Bilgi
              </Button>
            </div>
          </div>
          <div className="relative">
            <img
              src={heroImage}
              alt="Chat interface mockup"
              className="rounded-lg w-full"
              data-testid="img-hero"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
