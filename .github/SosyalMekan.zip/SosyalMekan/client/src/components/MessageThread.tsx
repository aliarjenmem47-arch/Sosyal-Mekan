import { ScrollArea } from "@/components/ui/scroll-area";
import MessageBubble from "./MessageBubble";
import MessageInput from "./MessageInput";
import UserAvatar from "./UserAvatar";
import { Button } from "@/components/ui/button";
import { Phone, Video, MoreVertical } from "lucide-react";

const mockMessages = [
  {
    id: "1",
    sender: "Ahmet Yılmaz",
    message: "Merhaba! Nasılsın?",
    timestamp: "10:15",
    isOwn: false,
  },
  {
    id: "2",
    sender: "Sen",
    message: "İyiyim, sen nasılsın?",
    timestamp: "10:16",
    isOwn: true,
  },
  {
    id: "3",
    sender: "Ahmet Yılmaz",
    message: "Ben de iyiyim. Bugün kahve içelim mi?",
    timestamp: "10:17",
    isOwn: false,
  },
  {
    id: "4",
    sender: "Sen",
    message: "Olur, saat kaçta uygun?",
    timestamp: "10:18",
    isOwn: true,
  },
  {
    id: "5",
    sender: "Ahmet Yılmaz",
    message: "15:00'te nasıl?",
    timestamp: "10:20",
    isOwn: false,
    media: { type: "image" as const, url: "" },
  },
  {
    id: "6",
    sender: "Sen",
    message: "Tamam, görüşürüz!",
    timestamp: "10:30",
    isOwn: true,
  },
];

export default function MessageThread() {
  return (
    <div className="flex flex-col h-screen">
      <div className="border-b p-4 flex items-center justify-between bg-background">
        <div className="flex items-center gap-3">
          <UserAvatar name="Ahmet Yılmaz" online={true} />
          <div>
            <h3 className="font-semibold">Ahmet Yılmaz</h3>
            <p className="text-xs text-muted-foreground">Çevrimiçi</p>
          </div>
        </div>
        <div className="flex gap-1">
          <Button size="icon" variant="ghost" data-testid="button-voice-call">
            <Phone className="h-5 w-5" />
          </Button>
          <Button size="icon" variant="ghost" data-testid="button-video-call">
            <Video className="h-5 w-5" />
          </Button>
          <Button size="icon" variant="ghost" data-testid="button-more-options">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {mockMessages.map((msg) => (
            <MessageBubble key={msg.id} {...msg} />
          ))}
        </div>
      </ScrollArea>
      <MessageInput />
    </div>
  );
}
