import UserAvatar from "./UserAvatar";
import { Badge } from "@/components/ui/badge";

interface ConversationItemProps {
  name: string;
  lastMessage: string;
  timestamp: string;
  avatar?: string;
  online?: boolean;
  unreadCount?: number;
  active?: boolean;
  onClick?: () => void;
}

export default function ConversationItem({
  name,
  lastMessage,
  timestamp,
  avatar,
  online,
  unreadCount = 0,
  active = false,
  onClick,
}: ConversationItemProps) {
  return (
    <div
      className={`flex items-center gap-3 p-3 rounded-md cursor-pointer hover-elevate active-elevate-2 ${
        active ? "bg-accent" : ""
      }`}
      onClick={onClick}
      data-testid={`conversation-${name}`}
    >
      <UserAvatar name={name} avatar={avatar} online={online} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2 mb-1">
          <span className="font-semibold text-sm truncate">{name}</span>
          <span className="text-xs text-muted-foreground shrink-0">{timestamp}</span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm text-muted-foreground truncate">{lastMessage}</p>
          {unreadCount > 0 && (
            <Badge className="shrink-0" data-testid="badge-unread">
              {unreadCount}
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}
