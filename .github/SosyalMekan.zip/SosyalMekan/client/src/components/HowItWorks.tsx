import { UserPlus, Users, MessageCircle } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: UserPlus,
    title: "Hesap Oluştur",
    description: "Hızlıca kayıt ol ve profilini oluştur",
  },
  {
    number: "02",
    icon: Users,
    title: "Arkadaş Ekle",
    description: "Arkadaşlarını bul ve bağlantı kur",
  },
  {
    number: "03",
    icon: MessageCircle,
    title: "Sohbet Et",
    description: "Mesajlaş, fotoğraf paylaş, eğlen!",
  },
];

export default function HowItWorks() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Nasıl Çalışır?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Üç basit adımda arkadaşlarınla sohbet etmeye başla
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className="text-center space-y-4"
              data-testid={`step-${index}`}
            >
              <div className="relative inline-flex items-center justify-center">
                <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
                  <step.icon className="h-10 w-10 text-primary" />
                </div>
                <div className="absolute -top-2 -right-2 h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                  {step.number}
                </div>
              </div>
              <h3 className="text-xl font-semibold">{step.title}</h3>
              <p className="text-muted-foreground">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
