import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, Image, Video } from "lucide-react";

export default function MessageInput() {
  const [message, setMessage] = useState("");

  const handleSend = () => {
    if (message.trim()) {
      console.log("Sending message:", message);
      setMessage("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="border-t p-4 bg-background">
      <div className="flex gap-2 items-end">
        <div className="flex gap-1">
          <Button
            size="icon"
            variant="ghost"
            data-testid="button-upload-image"
            onClick={() => console.log("Upload image clicked")}
          >
            <Image className="h-5 w-5" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            data-testid="button-upload-video"
            onClick={() => console.log("Upload video clicked")}
          >
            <Video className="h-5 w-5" />
          </Button>
        </div>
        <Textarea
          placeholder="Mesajını yaz..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          className="resize-none min-h-12 max-h-32"
          data-testid="input-message"
        />
        <Button
          onClick={handleSend}
          disabled={!message.trim()}
          data-testid="button-send"
        >
          <Send className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
