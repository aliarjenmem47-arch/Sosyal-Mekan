import { Image as ImageIcon, Video } from "lucide-react";
import UserAvatar from "./UserAvatar";

interface MessageBubbleProps {
  message: string;
  sender: string;
  timestamp: string;
  isOwn?: boolean;
  avatar?: string;
  media?: { type: "image" | "video"; url: string };
}

export default function MessageBubble({
  message,
  sender,
  timestamp,
  isOwn = false,
  avatar,
  media,
}: MessageBubbleProps) {
  return (
    <div
      className={`flex gap-3 ${isOwn ? "flex-row-reverse" : ""}`}
      data-testid={`message-${isOwn ? "own" : "other"}`}
    >
      {!isOwn && <UserAvatar name={sender} avatar={avatar} size="sm" />}
      <div className={`flex flex-col ${isOwn ? "items-end" : "items-start"} max-w-md`}>
        {!isOwn && <span className="text-xs font-semibold mb-1">{sender}</span>}
        <div
          className={`rounded-2xl px-4 py-2 ${
            isOwn
              ? "bg-primary text-primary-foreground rounded-tr-md"
              : "bg-muted rounded-tl-md"
          }`}
        >
          {media && (
            <div className="mb-2 rounded-md overflow-hidden">
              {media.type === "image" ? (
                <div className="relative bg-muted/50 rounded-md p-2 flex items-center gap-2">
                  <ImageIcon className="h-4 w-4" />
                  <span className="text-sm">Fotoğraf</span>
                </div>
              ) : (
                <div className="relative bg-muted/50 rounded-md p-2 flex items-center gap-2">
                  <Video className="h-4 w-4" />
                  <span className="text-sm">Video</span>
                </div>
              )}
            </div>
          )}
          <p className="text-sm">{message}</p>
        </div>
        <span className="text-xs text-muted-foreground mt-1">{timestamp}</span>
      </div>
    </div>
  );
}
