import { MessageSquare } from "lucide-react";

export default function Footer() {
  return (
    <footer className="py-12 border-t">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">ChatHub</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Arkadaşlarınızla bağlantıda kalmanın en kolay yolu.
            </p>
          </div>
          <div>
            <h3 className="font-semibold mb-4">Hızlı Bağlantılar</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="hover:text-foreground">
                  Hakkımızda
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  Özellikler
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  Yardım
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-4">Yasal</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="hover:text-foreground">
                  Kullanım Şartları
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  Gizlilik Politikası
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="pt-8 border-t text-center text-sm text-muted-foreground">
          © 2025 ChatHub. Tüm hakları saklıdır.
        </div>
      </div>
    </footer>
  );
}
